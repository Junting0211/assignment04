<?php 
$currentPage = "Assignment 04: Odd Student Out";
include "inc/html-top.inc";
?>

<body class="z-pattern">
<header class="persistent">
	<div class="container">
	<section>
		<!-- Primary Optical Area -->
		<h1>"Odd" Student "Out"</h1>
	</section>
	<section>
		<!-- Strong Follow Area -->				
		<h1>Team Seattle</h1>
	</section>
	</div>
</header>

<main>
	
	<section>
	<div class="slideshow">


  <div class="numbertext">1 / 3</div>
  <img class= "Slides" src="images/islomzhan.jpg" alt="islomzhan">


  <div class="numbertext">2 / 3</div>
  <img class= "Slides"src="images/dewey.jpg" alt="dewey">


  <div class="numbertext">3 / 3</div>
  <img class= "Slides"src="images/shelley.jpg" alt="shelley">


<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
<a class="next" onclick="plusSlides(1)">&#10095;</a>


	</section><!--.slider-->


	<section>
		<p>These three students, Islomzhan, Dewey and Xueying are University of Rochester seniors who are currently enrolling in CSC174 and having strong interests in web page designs. Two of them, Islomzhan and Dewey, have chosen Computer Science as their major. And Xueying, is very special among them since she is a Business Entrepreneurship major. </p>
	</section>
	
</main>

<footer class="persistent">
	<div class="container">
	<section>
		<!-- Weak Visual Area -->
		CSC 174: Advanced Front-end Web Design and Development
	</section>
	<section>
		<!-- Terminal Area -->
		<a href="subpage.php">Click Here to Learn More</a>
	</section>
	</div>
</footer>


<?php include "inc/scripts.php"; ?>
      <script src="sss/sss.js"></script>
      <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
      <script>
        $('.slider').sss();
      </script>

      <script>
        $( "#accordion" ).accordion({
          heightStyle: "content"
        });
      </script>
      
</body>
</html>
